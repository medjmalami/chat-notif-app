import { NotificationsLayout } from "@/components/notifications/notifications-layout"

export default function NotificationsPage() {
  return <NotificationsLayout />
}
